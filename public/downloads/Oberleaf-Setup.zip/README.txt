Oberleaf
========

1. Extract this whole zip into a folder (right-click > Extract All).
   Keep Oberleaf-Setup.bat and install.ps1 together.
2. Double-click Oberleaf-Setup.bat.
3. If Windows shows "Windows protected your PC", click "More info" and then
   "Run anyway". This appears because the script is not code-signed, not
   because anything is wrong with it.
4. If Windows asks for permission to install software, choose Yes.

The setup window stays open until you close it. If something fails it prints
the reason and the path to a log file - send that log when reporting a problem.

Source code: https://github.com/sahgyan9/Oberleaf
